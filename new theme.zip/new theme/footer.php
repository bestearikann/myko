
   <div style=" display: flex; justify-content: space-around; align-items: center; font-family: sans-serif; flex-wrap: wrap; ">
        <div style=" align-items: center; margin-top: 35px; flex-wrap: wrap;">
<img style="height: 100px; margin: 0 0 20px 40px;"  src="/images/Frame.png" alt="">
<p style="padding-top: 20px; margin: 0 0 20px 40px;">0 (123) 456 78 90   info@radiatorinfo.com</p>

</div>
<div style="text-align: left;">
<strong style=" max-width: 300px; width: 100%; text-align: left;  flex-wrap: wrap; margin: 10px;">&nbsp;&nbsp;&nbsp;İÇERİK TÜRLERİ</strong>
<Ul>Lorem ipsum</Ul>
<Ul>Lorem ipsum</Ul>
<Ul>Lorem ipsum</Ul>
<Ul>Lorem ipsum</Ul>
</div>
    </div>
<hr  style="margin: 10px;">
<div style="max-width: 1400px; width: 100%; justify-content: space-evenly; align-items: center; display: flex;  font-family: sans-serif; font-size: small; flex-wrap: wrap;">&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;
<span>Radiator Info 2022</span>
<span>Kullanım Koşulları</span>
<span>Gizlilik Politikası</span>
<span>Lorem ipsum dolor sit amet, consectetur adipiscing elit</span>
<div style="margin-left:25px">
<img style="margin: 15px ;" src="/images/Frame1.png" alt="">
</div>


</div>
</div>
</div>
</body>
</html>