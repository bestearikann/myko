
<?php get_header(); ?>

<div style="width: 100%;">
    <div style="max-width: 1400px; width: 100%; margin: auto; font-family: sans-serif; flex-wrap: wrap; ">
<div style=" max-width: 1400px; width: 100%; justify-content: center; align-items: center; display: flex; flex-wrap: wrap; font-family: sans-serif;" >
</div>
<div class="img"   style=" max-width: 1400px; width: 100%; display: flex; justify-content: center; margin:auto;  flex-wrap: wrap;">
<img  style="cursor: pointer;  max-width: 560px; width: 100%; margin: 15px;" src="images/Rectangle 18.png" alt="">

<img style="cursor: pointer;  max-width: 350px; width: 100%; margin: 15px;" src="images/Rectangle 18.png" alt="">

</div>
<div style=" max-width: 1280px; width: 100%; display: flex; justify-content: space-around; font-family: sans-serif;  align-items: center; flex-wrap: wrap; ">
    <div style=" max-width: 300px;  width: 100%;">
        
    <h3 style="color: #A36D4D; display: flex; align-items: center;">
     <hr style="height: 20px; width: 1px; margin-right: 5px; background-color: #A36D4D;">
     LOREM IPSUM &nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;

    </h3>
    <span style="font-weight: bold; color: #603913;">&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;Lorem Ipsum Dolor Sit Amet</span>
<p  style="color: #909090;">&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;MART 17, 2022</p>
</div>

<div style=" max-width: 300px; width: 100%; font-family: sans-serif; ">
    <h3 style="color: #A36D4D; display: flex; align-items: center;">
        <hr style="height: 20px; width: 1px; margin-right: 5px; background-color: #A36D4D; ">
        LOREM IPSUM &nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;
        
   
       </h3>
       <span style="font-weight: bold; color: #603913;">&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;Lorem Ipsum Dolor Sit Amet</span>
       <p  style="color: #909090;">&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;MART 17, 2022</p>
</div>
</div>
<section>
<?php if ( have_posts() ) : ?>
<?php while ( have_posts() ) : the_post(); ?>
  <div id="post-<?php the_ID(); ?>" <?php post_class(); ?>>
    <div class="post-header">
       <div class="date"><?php the_time( 'M j y' ); ?></div>
       <h2><a href="<?php the_permalink(); ?>" rel="bookmark" title="Permanent Link to <?php the_title_attribute(); ?>"><?php the_title(); ?></a></h2>
       <div class="author"><?php the_author(); ?></div>
    </div><!--end post header-->
    <div class="entry clear">
       <?php if ( function_exists( 'add_theme_support' ) ) the_post_thumbnail(); ?>
       <?php the_content(); ?>
       <?php edit_post_link(); ?>
       <?php wp_link_pages(); ?> </div>
    <!--end entry-->
    <div class="post-footer">
       <div class="comments"><?php comments_popup_link( 'Leave a Comment', '1 Comment', '% Comments' ); ?></div>
    </div><!--end post footer-->
    </div><!--end post-->
<?php endwhile; /* rewind or continue if all posts have been fetched */ ?>
    <div class="navigation index">
       <div class="alignleft"><?php next_posts_link( 'Older Entries' ); ?></div>
       <div class="alignright"><?php previous_posts_link( 'Newer Entries' ); ?></div>
    </div><!--end navigation-->
<?php else : ?>
<?php endif; ?>
</section>


<div style="display: flex; justify-content: center; margin: 15px; flex-wrap: wrap; font-family: sans-serif;">
    <img style="cursor: pointer;   max-width: 320px; width: 100%; margin: 15px;" src="images/Rectangle 18.png" alt="">
    
    <img style="cursor: pointer;   max-width: 320px; width: 100%; margin: 15px;" src="images/Rectangle 18.png" alt="">
    <img style="cursor: pointer;  max-width: 320px; width: 100%; margin: 15px;" src="images/Rectangle 18.png" alt="">
    

</div>
<div style=" max-width: 1280px; width: 100%; display: flex; justify-content: space-evenly; margin: auto; font-family: sans-serif;  align-items: center; flex-wrap: wrap; ">
    <div style=" max-width: 300px;  width: 100%;">
        
    <h3 style="color: #A36D4D; display: inline-flex; align-items: center;">
     <hr style="height: 20px; width: 1px; margin-right: 5px; background-color: #A36D4D;">
     LOREM IPSUM
    </h3>
    <p style="font-weight: bold; color: #603913;">Lorem Ipsum Dolor Sit Amet</p>
<p  style="color: #909090;">MART 17, 2022</p>
</div>
<div style=" max-width: 300px;  width: 100%;">
        
    <h3 style="color: #A36D4D; display: inline-flex; align-items: center; ">
     <hr style="height: 20px; width: 1px; margin-right: 5px; background-color: #A36D4D;">
     LOREM IPSUM

    </h3>
    <p style="font-weight: bold; color: #603913;">Lorem Ipsum Dolor Sit Amet</p>
    <p  style="color: #909090;">MART 17, 2022</p>

</div>
<div style=" max-width: 300px; width: 100%; font-family: sans-serif; ">
    <h3 style="color: #A36D4D; display: inline-flex; align-items: center;">
        <hr style="height: 20px; width: 1px; margin-right: 5px; background-color: #A36D4D; ">
        LOREM IPSUM 
        
   
       </h3>
       <p style="font-weight: bold; color: #603913;">Lorem Ipsum Dolor Sit Amet</p>
       <p  style="color: #909090;">MART 17, 2022</p>
</div>
</div>
<div style="display: flex; justify-content: center; margin: 15px; flex-wrap: wrap; ">
    <img style=" cursor: pointer;  max-width: 320px; width: 100%; margin: 15px;" src="images/Rectangle 18.png" alt="">
    
    <img style="cursor: pointer;   max-width: 320px; width: 100%;  margin: 15px;" src="images/Rectangle 18.png" alt="">
    <img style="cursor: pointer;   max-width: 320px; width: 100%;  margin: 15px;" src="images/Rectangle 18.png" alt="">
    

</div>
<div style="flex-wrap: wrap; display: flex; margin: auto; padding: 20px; justify-content: space-around">
    
    <div style=" max-width: 1280px; width: 100%; display: flex; justify-content: space-evenly; margin: auto; font-family: sans-serif;  align-items: center; flex-wrap: wrap; ">
        <div style=" max-width: 300px;  width: 100%;">
            
        <h3 style="color: #A36D4D; display: inline-flex; align-items: center;">
         <hr style="height: 20px; width: 1px; margin-right: 5px; background-color: #A36D4D;">
         LOREM IPSUM 
        </h3>
        <p style="font-weight: bold; color: #603913;">Lorem Ipsum Dolor Sit Amet</p>
    <p  style="color: #909090;">MART 17, 2022</p>
    </div>
    <div style=" max-width: 300px;  width: 100%;">
            
        <h3 style="color: #A36D4D; display: inline-flex; align-items: center; ">
         <hr style="height: 20px; width: 1px; margin-right: 5px; background-color: #A36D4D;">
         LOREM IPSUM 
    
        </h3>
        <p style="font-weight: bold; color: #603913;">Lorem Ipsum Dolor Sit Amet</p>
        <p  style="color: #909090;">MART 17, 2022</p>
    
    </div>
    <div style=" max-width: 300px; width: 100%; font-family: sans-serif; ">
        <h3 style="color: #A36D4D; display: inline-flex; align-items: center;">
            <hr style="height: 20px; width: 1px; margin-right: 5px; background-color: #A36D4D; ">
            LOREM IPSUM 
            
       
           </h3>
           <p style="font-weight: bold; color: #603913;">Lorem Ipsum Dolor Sit Amet</p>
           <p  style="color: #909090;">MART 17, 2022</p>
    </div>
    </div>
   
</div>
<div style=" background-color: #F5F5F5; max-width: 1400px; width: 100%; display: flex; padding-bottom: 35px; align-items: center;  justify-content: space-evenly; flex-wrap: wrap; font-family: sans-serif; color: #A36D4D; ">
    <div style="text-align: center; justify-content: center; align-items: center;">
<h2 style="padding: 25px 0 0 25px; ">LOREM IPSUM DOLOR SIT AMET</h2>
<span>Lorem ipsum dolor sit amet <br>
    consectetur adipiscing elit</span>
</div>
    <input style="padding: 15px 65px 15px 85px; max-width:  360px; width: 100%; margin: 8px;   color: #A36D4D; border: none; font-family: sans-serif; justify-content: center; align-items: center; text-align: center;" type="email" value="Your email address">
<input style="color: #FFFFFF; background-color: #444444; align-items: center; padding: 13px 29px 15px 29px; font-family: sans-serif;" type="submit" value="SUBMIT">
</div>
<div class="img"   style=" max-width: 1400px; width: 100%; display: flex; justify-content: center; margin: auto;  flex-wrap: wrap;">
    <img  style="cursor: pointer; max-width: 480px; width: 100%; margin: 15px;" src="images/Rectangle 18.png" alt="">
    
    <img style="cursor: pointer; max-width: 480px; width: 100%; margin: 15px;" src="images/Rectangle 18.png" alt="">
    
    </div>
    <div style="max-width: 1260px; display: flex; justify-content: space-evenly; font-family: sans-serif; flex-wrap: wrap;">
       
           </h3>
           <div style=" max-width: 280px; width: 100%; height: 200px; margin-bottom: 30px; align-items: center; padding-bottom: 10px;  text-align: left;  justify-content: space-evenly; flex-wrap: wrap;">
            <h3 style="color: #A36D4D; display: inline-flex; align-items: center;">
             <hr style="height: 20px; width: 1px; margin-right: 5px; background-color: #A36D4D;">
             LOREM IPSUM 
        
            </h3>
            <div style=" padding-left: 10px; justify-content: center; flex-wrap: wrap;">
            <p style="font-weight: bold; color: #603913;">Lorem Ipsum Dolor Sit Amet</p>
            <p style="color: #909090;">MART 17, 2022</p>
        </div>
        </div>
        <div style=" max-width: 280px; width: 100%; align-items: center; justify-content: space-evenly; text-align: left; flex-wrap: wrap; ">
            <h3 style="color: #A36D4D; display: inline-flex; align-items: center;">
             <hr style="height: 20px; width: 1px; margin-right: 5px; background-color: #A36D4D; flex-wrap: wrap;">
             LOREM IPSUM 
        
            </h3>
            
            <div style=" padding-left: 10px; justify-content: center; flex-wrap: wrap;">
            <p style="font-weight: bold; color: #603913; ">Lorem Ipsum Dolor Sit Amet</p>
            <p  style="color: #909090;">MART 17, 2022</p>
            <div style="width: 20px;"></div>
        </div>
        </div>
        </div>
        
     
    </div>

    <?php get_footer(); ?>