<!DOCTYPE html>
<html lang="en">
<head>
    <meta charset="UTF-8">
    <meta http-equiv="X-UA-Compatible" content="IE=edge">
    <meta name="viewport" content="width=device-width, initial-scale=1.0">
<link rel="stylesheet" href="/index.css">
    <title>Myko</title>
</head>
<body>
    <div style="width: 100%;">
    <div style="max-width: 1400px; width: 100%; margin: auto; font-family: sans-serif; flex-wrap: wrap; ">
<div style=" max-width: 1400px; width: 100%; justify-content: center; align-items: center; display: flex; flex-wrap: wrap; font-family: sans-serif;" >
<img  style="justify-content: center; align-items: center; max-width: 250px; width: 100%; margin-bottom: 30px;" src="/images/Frame.png" alt="">
